/**
 * 拓展ts原生类
 */
var Extensions;
(function (Extensions) {
    //#region
    /**
     * 随机一个范围内的数字（整数），范围的左边是闭区间，右边是开区间
     */
    //#endregion
    function random(min, max) {
        var d = Math.floor(max) - Math.floor(min);
        return min + Math.floor(Math.random() * d);
    }
    function getValue(obj, lambda) {
        if (!lambda) {
            return obj;
        }
        else {
            return lambda(obj);
        }
    }
    function defineToObject(methodName, value) {
        Object.defineProperty(Object.prototype, methodName, {
            enumerable: false,
            configurable: true,
            writable: true,
            value: value
        });
    }
    function initExtensions() {
        Array.prototype.pushRange = function (items) {
            if (!items || items.length == 0) {
                return;
            }
            for (var _i = 0, items_1 = items; _i < items_1.length; _i++) {
                var x = items_1[_i];
                this.push(x);
            }
        };
        Array.prototype.contains = function (item) {
            return this.indexOf(item) >= 0;
        };
        Array.prototype.first = function (lambda) {
            if (!lambda && this.length > 0) {
                return this[0];
            }
            for (var _i = 0, _a = this; _i < _a.length; _i++) {
                var x = _a[_i];
                if (lambda(x)) {
                    return x;
                }
            }
            return null;
        };
        Array.prototype.last = function (lambda) {
            if (!lambda && this.length > 0) {
                return this[this.length - 1];
            }
            for (var i = this.length - 1; i >= 0; i--) {
                if (lambda(this[i])) {
                    return this[i];
                }
            }
            return null;
        };
        Array.prototype.max = function (lambda) {
            var result = null;
            if (this.length == 0)
                return result;
            var max = getValue(this[0], lambda);
            result = this[0];
            for (var i = 1; i < this.length; i++) {
                var temp = getValue(this[i], lambda);
                if (temp > max) {
                    max = temp;
                    result = this[i];
                }
            }
            return result;
        };
        Array.prototype.min = function (lambda) {
            var result = null;
            if (this.length == 0)
                return result;
            var min = getValue(this[0], lambda);
            result = this[0];
            for (var i = 1; i < this.length; i++) {
                var temp = getValue(this[i], lambda);
                if (temp < min) {
                    min = temp;
                    result = this[i];
                }
            }
            return result;
        };
        Array.prototype.Contains = function (lambda) {
            return this.first(lambda) != null;
        };
        Array.prototype.remove = function (item) {
            var ndx = this.indexOf(item);
            if (ndx >= 0) {
                var last = this.length - 1;
                var temp = this[last];
                this[last] = this[ndx];
                this[ndx] = temp;
                this.pop();
            }
        };
        Array.prototype.removeBySlice = function (item) {
            var ndx = this.indexOf(item);
            if (ndx >= 0) {
                this.splice(ndx, 1);
            }
        };
        Array.prototype.Remove = function (lambda) {
            var _this = this;
            var delectItem = function (idx) {
                var last = _this.length - 1;
                var temp = _this[last];
                _this[last] = _this[idx];
                _this[idx] = temp;
                _this.pop();
            };
            var delectCount = 0;
            for (var i = 0; i < this.length; i++) {
                if (lambda(this[i])) {
                    delectItem(i);
                    delectCount++;
                    i--;
                }
            }
            return delectCount;
        };
        Array.prototype.clear = function () {
            var cnt = this.length;
            for (var i = 0; i < cnt; i++) {
                this.pop();
            }
        };
        Array.prototype.select = function (lambda) {
            return this.map(lambda);
        };
        Array.prototype.where = function (lambda) {
            return this.filter(lambda);
        };
        Array.prototype.count = function (lambda) {
            if (!lambda)
                return this.length;
            return this.where(lambda).length;
        };
        Array.prototype.toDictionary = function (lambda) {
            var obj = {};
            for (var _i = 0, _a = this; _i < _a.length; _i++) {
                var x = _a[_i];
                obj[lambda(x)] = x;
            }
            return obj;
        };
        //TODO:luowende 暂时实现方法，存在丢弃构造函数的bug
        Array.prototype.clone = function () {
            // return JSON.parse(JSON.stringify(this));
            return this.slice(0);
        };
        Array.prototype.Shuffle = function () {
            for (var i = 0; i < this.length; i++) {
                var randIdx = random(0, this.length);
                //当前元素与随机一个位置元素交换位置
                var temp = this[i];
                this[i] = this[randIdx];
                this[randIdx] = temp;
            }
        };
        Array.prototype.shuffle = function () {
            var newArr = this.clone();
            newArr.Shuffle();
            return newArr;
        };
        Array.prototype.SortAsc = function (lambda) {
            this.sort(function (a, b) { return getValue(a, lambda) - getValue(b, lambda); });
        };
        Array.prototype.SortDesc = function (lambda) {
            this.sort(function (a, b) { return getValue(b, lambda) - getValue(a, lambda); });
        };
        Array.prototype.sortAsc = function (lambda) {
            var newArr = this.clone();
            newArr.SortAsc(lambda);
            return newArr;
        };
        Array.prototype.sortDesc = function (lambda) {
            var newArr = this.clone();
            newArr.SortDesc(lambda);
            return newArr;
        };
        Array.prototype.DeleteSame = function (lambda) {
            var hash = {};
            var newArr = [];
            for (var _i = 0, _a = this; _i < _a.length; _i++) {
                var item = _a[_i];
                var value = lambda(item);
                if (hash[value])
                    continue;
                newArr.push(item);
                hash[value] = 1;
            }
            return newArr;
        };
        Array.prototype.AllSame = function (arr) {
            for (var index = 0; index < arr.length; index++) {
                var element = arr[index];
                if (this.indexOf(element) != -1) {
                    return false;
                }
            }
            return true;
        };
        egret.DisplayObjectContainer.prototype.removeSelf = function () {
            if (this.parent) {
                this.parent.removeChild(this);
            }
        };
        var colorFlilter = new egret.ColorMatrixFilter([
            0.3, 0.6, 0, 0, 0,
            0.3, 0.6, 0, 0, 0,
            0.3, 0.6, 0, 0, 0,
            0, 0, 0, 1, 0
        ]);
        Object.defineProperty(egret.DisplayObject.prototype, "gray", {
            set: function (v) {
                this.filters = v ? [colorFlilter] : [];
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(egret.DisplayObject.prototype, "enabeled", {
            set: function (v) {
                this.touchEnabled = v;
                this.filters = v ? [] : [colorFlilter];
            },
            enumerable: false,
            configurable: true
        });
    }
    Extensions.initExtensions = initExtensions;
})(Extensions || (Extensions = {}));
//# sourceMappingURL=Extensions.js.map