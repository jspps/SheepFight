var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var RoleItem = (function (_super) {
    __extends(RoleItem, _super);
    function RoleItem() {
        var _this = _super.call(this) || this;
        _this.skinName = "RoleSkin";
        return _this;
    }
    Object.defineProperty(RoleItem.prototype, "sheepInfo", {
        get: function () {
            return this._sheepInfo;
        },
        set: function (v) {
            this._sheepInfo = v;
            this._role.source = GameData.getSheepSource(v.index);
        },
        enumerable: true,
        configurable: true
    });
    RoleItem.prototype.move = function (addTween) {
        if (addTween === void 0) { addTween = true; }
        egret.Tween.removeTweens(this);
        var basic = GameData.loginInfo.client_sv_basic;
        var mY = basic * this.sheepInfo.distance;
        var initPos = (GameData.loginInfo.lens_way - this.sheepInfo.endDistance) * basic;
        var endy = Math.floor(initPos + mY);
        if (this.sheepInfo.runTo != GameData.loginInfo.sesid) {
            // 向敌人靠近
            var max = GameData.loginInfo.client_max_lens;
            endy = Math.floor(max - endy);
            // console.log("==Toenm = " + initPos + ",mY =" + mY + ",endy = " + endy);
        }
        if (endy == this.y)
            return;
        if (addTween)
            egret.Tween.get(this).to({ y: endy }, GameData.loginInfo.client_duration);
        else
            this.y = endy;
    };
    RoleItem.prototype.baseGC = function () {
        this.removeSelf();
    };
    return RoleItem;
}(eui.Component));
__reflect(RoleItem.prototype, "RoleItem");
//# sourceMappingURL=RoleItem.js.map