var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var WaitSheep = (function (_super) {
    __extends(WaitSheep, _super);
    function WaitSheep() {
        var _this = _super.call(this) || this;
        _this.skinName = "WaitSheepSkin";
        return _this;
    }
    WaitSheep.prototype.init = function (sheepInfo) {
        this.visible = true;
        this._role.source = GameData.getSheepSource(sheepInfo.index);
        this._power.text = sheepInfo.power + ""; //力量值
    };
    return WaitSheep;
}(eui.Component));
__reflect(WaitSheep.prototype, "WaitSheep");
//# sourceMappingURL=WaitSheep.js.map