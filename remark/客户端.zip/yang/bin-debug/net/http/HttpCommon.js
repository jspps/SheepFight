var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var HttpCommon = (function () {
    function HttpCommon(sendVO) {
        this._sendVO = sendVO;
        var request = new egret.HttpRequest();
        request.responseType = egret.HttpResponseType.TEXT;
        request.setRequestHeader("content-type", "application/x-www-form-urlencoded;charset=utf-8");
        // if(GameData.recLoginServerData != null && GameData.recLoginServerData.session_id != null && GameData.recLoginServerData.session_id != ""){
        // 	request.setRequestHeader("Cookie","PHPSESSID="+GameData.recLoginServerData.session_id);
        // }
        request.open(this._sendVO.sendURL, egret.HttpMethod.POST);
        request.send(this._sendVO.dataObj);
        // console.log("发送Http数据:",this._sendVO.sendURL,JSON.stringify(this._sendVO.dataObj));
        request.addEventListener(egret.Event.COMPLETE, this.onPostComplete, this);
        request.addEventListener(egret.IOErrorEvent.IO_ERROR, this.onPostIOError, this);
        request.addEventListener(egret.ProgressEvent.PROGRESS, this.onPostProgress, this);
    }
    HttpCommon.prototype.onPostComplete = function (event) {
        var request = event.currentTarget;
        // console.log("== http = :" + request.response);
        var data = JSON.parse(request.response);
        if (data["code"] != GameData.success) {
            Toast.launch(data["msg"]["tip"]);
            return;
        }
        if (this._sendVO.callBack != null) {
            this._sendVO.callBack(data);
        }
        this._sendVO.gc();
    };
    HttpCommon.prototype.onPostIOError = function (event) {
        console.log("post error : ", event);
    };
    HttpCommon.prototype.onPostProgress = function (event) {
        // console.log("post progress : " + Math.floor(100 * event.bytesLoaded / event.bytesTotal) + "%");
    };
    return HttpCommon;
}());
__reflect(HttpCommon.prototype, "HttpCommon");
//# sourceMappingURL=HttpCommon.js.map