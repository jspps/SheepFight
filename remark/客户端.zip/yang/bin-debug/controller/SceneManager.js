var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var SceneManager = (function (_super) {
    __extends(SceneManager, _super);
    function SceneManager() {
        var _this = _super.call(this) || this;
        _this.init();
        return _this;
    }
    SceneManager.prototype.init = function () {
        this.sceneLayer = new egret.Sprite();
        this.addChild(this.sceneLayer);
        this.popupLayer = new egret.Sprite();
        this.addChild(this.popupLayer);
        this.topLayer = new egret.Sprite();
        this.addChild(this.topLayer);
        // 默认添加开始场景
        this.changeScene(SceneType.LOGIN_SCENE);
    };
    // 实例化单例获取方法
    SceneManager.getInstance = function () {
        if (!SceneManager.instance) {
            SceneManager.instance = new SceneManager();
        }
        return SceneManager.instance;
    };
    SceneManager.prototype.initScene = function (type) {
        switch (type) {
            case SceneType.LOGIN_SCENE:
                if (this[type] == null) {
                    this[type] = new LoginScene();
                }
                break;
            case SceneType.GAME_SCENE:
                if (this.gameScene == null) {
                    this.gameScene = new GameScene();
                }
                break;
            case SceneType.WAIT_PLAYER:
                if (this[type] == null) {
                    this[type] = new WaitPlyer();
                }
                break;
        }
    };
    // 切换场景
    SceneManager.prototype.changeScene = function (type) {
        console.log(">>changeScene:", this.preScene, type);
        if (this.preScene && this.preScene == this[type]) {
            return;
        }
        // 释放当前场景资源
        // if (this.preScene) {
        //     this.preScene.baseGC();
        //     this.sceneLayer.removeChild(this.preScene);
        // }
        // 添加下一个场景
        this.curSceneType = type;
        this.initScene(type);
        // console.log(">>changeScene:",type,this[type]);
        this.sceneLayer.addChild(this[type]);
        this[type].init();
        this.preScene = this[type];
    };
    SceneManager.prototype.openTime = function (duration) {
        var _this = this;
        if (duration === void 0) { duration = 1000; }
        GameData.loginInfo.client_duration = duration;
        this._timeId = setInterval(function () {
            _this.startTime();
        }, duration);
    };
    SceneManager.prototype.clearTime = function () {
        clearInterval(this._timeId);
    };
    SceneManager.prototype.reOpenTime = function (duration) {
        if (duration === void 0) { duration = 1000; }
        this.clearTime();
        this.openTime(duration);
    };
    SceneManager.prototype.startTime = function () {
        //请求心跳
        this.httpHeartBeat();
        if (this.gameScene && this.gameScene.parent) {
            this.gameScene.loop();
        }
    };
    SceneManager.prototype.httpHeartBeat = function () {
        var _this = this;
        var obj = "&sesid=" + GameData.loginInfo.sesid;
        NetManager.getInstance().httpSendData(NetManager.HTTP_HEARTBEAT, obj, function (data) {
            var msg = data["msg"];
            if (msg && msg["isEnd"]) {
                if (msg["isWin"]) {
                    Toast.launch("\u606D\u559C\u4F60\uFF0C\u53D6\u5F97\u80DC\u5229!");
                }
                else {
                    Toast.launch("\u5F88\u9057\u61BE\uFF0C\u6311\u6218\u5931\u8D25\uFF01");
                }
                _this.reOpenTime();
                return;
            }
            GameData.loginInfo.update(msg);
            if (msg && msg["start"] == 1) {
                if (_this.waitPlayer)
                    _this.waitPlayer.baseGC();
                _this.reOpenTime(200);
                _this.changeScene(SceneType.GAME_SCENE);
            }
            if (_this.gameScene && _this.gameScene.parent) {
                _this.gameScene.updateAllSheepInfo();
            }
        });
    };
    return SceneManager;
}(egret.Sprite));
__reflect(SceneManager.prototype, "SceneManager");
//# sourceMappingURL=SceneManager.js.map