// class PopUpManager {
// 	private static instance: PopUpManager;
// 	// 实例化单例获取方法
// 	public static getInstance(): PopUpManager{
// 		if(!PopUpManager.instance){
// 			PopUpManager.instance = new PopUpManager();
// 		}
// 		return PopUpManager.instance;
// 	}
// 	public constructor() {
// 	}
// 	public static addView(view:eui.Component){
// 		var layer:egret.Sprite = SceneManager.getInstance().getPopupLayer();
// 		if(!layer.contains(view)){
// 			var baseImg:eui.Image = new eui.Image("bj_jpg");
// 			baseImg.width = 750;
// 			baseImg.height = 1624;
// 			baseImg.y = -145;
// 			layer.addChild(baseImg);
// 			view.x = (750-view.width)/2;
// 			view.y = (1334-view.height)/2;
// 			layer.addChild(view);
// 		}
// 	}
// 	public static removeView(view:eui.Component){
// 		var layer:egret.Sprite = SceneManager.getInstance().getPopupLayer();
// 		if(layer.contains(view)){
// 			layer.removeChild(view);
// 		}
// 	}
// } 
//# sourceMappingURL=PopUpManager.js.map