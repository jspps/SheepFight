var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var NetManager = (function () {
    function NetManager() {
        this.httpServerUrl = "http://127.0.0.1:8080/SheepFight/Svlet/Game"; //正式服地址 60.205.217.89  127.0.0.1
        this.isSocketOpen = false;
    }
    // 实例化单例获取方法
    NetManager.getInstance = function () {
        if (!NetManager.instance) {
            NetManager.instance = new NetManager();
        }
        return NetManager.instance;
    };
    /**
     * http发送数据
     * @param url 地址
     * @param data 数据
     * @param callBack 回调函数
     */
    NetManager.prototype.httpSendData = function (msgName, data, callBack) {
        var url = this.httpServerUrl;
        var strData = "cmd=" + msgName + data;
        var sendVO = new HttpSendVO(url, strData, callBack);
        new HttpCommon(sendVO);
    };
    /**
     * 获取服务器时间
     */
    NetManager.HTTP_SERVER_TIME = 100;
    /**
     * 登陆
     */
    NetManager.HTTP_LOGIN = 1000;
    /**
     * 放羊
     */
    NetManager.HTTP_DOWN_SHEEP = 1010;
    /**
     * 心跳
     */
    NetManager.HTTP_HEARTBEAT = 1001;
    return NetManager;
}());
__reflect(NetManager.prototype, "NetManager");
//# sourceMappingURL=NetManager.js.map