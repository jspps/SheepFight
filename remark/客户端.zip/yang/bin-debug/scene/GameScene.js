var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var GameScene = (function (_super) {
    __extends(GameScene, _super);
    function GameScene() {
        var _this = _super.call(this) || this;
        _this.skinName = "GameSceneSkin";
        return _this;
    }
    GameScene.prototype.init = function () {
        this._sheeps = [];
        for (var i = 1; i <= 5; i++) {
            this["_row" + i].touchChildren = false;
            this["_row" + i].addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickRow, this);
        }
        this._selfHp.minimum = this._enemyHp.minimum = 0;
        this._selfHp.maximum = this._enemyHp.maximum = 100;
        this._selfHp.value = this._enemyHp.value = 100;
        this.updateInfo();
    };
    GameScene.prototype.updateInfo = function () {
        this.showWaitSheep();
        this.showAge();
    };
    //展示等待区羊
    GameScene.prototype.showWaitSheep = function () {
        var _this = this;
        var mySheeps = GameData.loginInfo.listWaitSelf;
        var enemySheeps = GameData.loginInfo.listWaitEnemy;
        for (var i = 0; i < 3; i++) {
            this["_selfWait" + i].visible = false;
        }
        this._enemyWait.visible = false;
        if (mySheeps) {
            mySheeps.forEach(function (sheepInfo, index) {
                _this["_selfWait" + index].init(sheepInfo);
            });
        }
        if (enemySheeps && enemySheeps.length) {
            this._enemyWait.init(enemySheeps[0]);
        }
    };
    GameScene.prototype.showAge = function () {
        this._selfHp.value = GameData.loginInfo.playerInfo.forage;
        this._enemyHp.value = GameData.loginInfo.enemy.forage;
    };
    GameScene.prototype.onClickRow = function (e) {
        var target = e.target;
        var row = 0;
        for (var i = 1; i <= 5; i++) {
            if (target == this["_row" + i]) {
                row = i;
                break;
            }
        }
        console.log(">>placeSheep", row);
        this.placeSheep(row);
    };
    GameScene.prototype.placeSheep = function (row) {
        var mySheeps = GameData.loginInfo.listWaitSelf;
        if (mySheeps && mySheeps.length) {
            var sheep_1 = mySheeps[0];
            var obj = "&sesid=" + GameData.loginInfo.sesid + "&sheepId=" + sheep_1.id + "&runway=" + row;
            NetManager.getInstance().httpSendData(NetManager.HTTP_DOWN_SHEEP, obj, function (data) {
                mySheeps.remove(sheep_1);
            });
        }
        else {
            Toast.launch("\u7B49\u5F85\u533A\u6682\u65F6\u6CA1\u6709\u7F8A");
        }
    };
    //更新所有的羊信息
    GameScene.prototype.updateAllSheepInfo = function () {
        this.updateInfo(); //更新界面信息
        //更新场上的羊
        this._deleteSheeps = [];
        while (this._sheeps.length) {
            this._deleteSheeps.push(this._sheeps.pop());
        }
        var selfRun = GameData.loginInfo.listRunning;
        this.updateRunSheep(selfRun);
        var sheepCount = this._deleteSheeps.length;
        for (var i = sheepCount - 1; i >= 0; i--) {
            var sheep = this._deleteSheeps[i];
            sheep.baseGC();
        }
    };
    GameScene.prototype.updateRunSheep = function (runList) {
        for (var i = 0; i < runList.length; i++) {
            var sheepInfo = runList[i];
            var findSheep = this.findMoveSheep(sheepInfo.id);
            if (findSheep) {
                findSheep.sheepInfo = sheepInfo;
                if (sheepInfo.isRunning) {
                    findSheep.move();
                }
                this._sheeps.push(findSheep);
                this["_row" + sheepInfo.runway].addChild(findSheep);
            }
            else {
                var sheepItem = Pool.getItemByClass("sheep", SheepItem);
                sheepItem.sheepInfo = sheepInfo;
                this["_row" + sheepInfo.runway].addChild(sheepItem);
                this._sheeps.push(sheepItem);
                sheepItem.move(false);
            }
        }
    };
    GameScene.prototype.findMoveSheep = function (sheepId) {
        var sheepCount = this._deleteSheeps.length;
        for (var i = sheepCount - 1; i >= 0; i--) {
            var sheep = this._deleteSheeps[i];
            if (sheep.sheepInfo.id == sheepId) {
                this._deleteSheeps.remove(sheep);
                return sheep;
            }
        }
        return null;
    };
    GameScene.prototype.updateSheep = function (sheep, sheepInfo) {
        sheep.sheepInfo = sheepInfo;
        sheep.move();
    };
    GameScene.prototype.loop = function () {
        // this._sheeps.forEach(sheep => {
        // 	sheep.move();
        // });
    };
    GameScene.prototype.baseGC = function () {
        for (var i = 1; i <= 5; i++) {
            this["_row" + i].removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickRow, this);
        }
        this.removeSelf();
    };
    return GameScene;
}(eui.Component));
__reflect(GameScene.prototype, "GameScene", ["IBaseGC"]);
//# sourceMappingURL=GameScene.js.map