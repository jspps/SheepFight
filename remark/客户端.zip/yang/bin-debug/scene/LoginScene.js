var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var LoginScene = (function (_super) {
    __extends(LoginScene, _super);
    function LoginScene() {
        var _this = _super.call(this) || this;
        _this.skinName = "loginSkin";
        return _this;
    }
    LoginScene.prototype.init = function () {
        this._account.text = "sun1";
        this._loginBtn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.loginClick, this);
    };
    LoginScene.prototype.loginClick = function () {
        var _this = this;
        if (this._account.text.length <= 0 || this._password.text.length <= 0) {
            Toast.launch("\u8D26\u53F7\u5BC6\u7801\u4E0D\u80FD\u4E3A\u7A7A");
            return;
        }
        var obj = "&lgid=" + this._account.text + "&lgpwd=" + this._password.text;
        NetManager.getInstance().httpSendData(NetManager.HTTP_LOGIN, obj, function (data) {
            GameData.loginInfo = new LoginInfo(data["msg"]);
            SceneManager.getInstance().reOpenTime();
            _this.baseGC();
        });
    };
    LoginScene.prototype.baseGC = function () {
        this._loginBtn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.loginClick, this);
        this.removeSelf();
        SceneManager.getInstance().changeScene(SceneType.WAIT_PLAYER);
    };
    return LoginScene;
}(eui.Component));
__reflect(LoginScene.prototype, "LoginScene", ["IBaseGC"]);
//# sourceMappingURL=LoginScene.js.map