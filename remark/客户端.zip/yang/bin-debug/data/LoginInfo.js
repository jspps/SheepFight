var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var LoginInfo = (function (_super) {
    __extends(LoginInfo, _super);
    function LoginInfo(data) {
        var _this = _super.call(this, data) || this;
        _this.lens_way = 1;
        _this.client_max_lens = 1000; // 客户端 跑道总长
        _this.client_sv_basic = 1; // 客户端 - 服务器 比例值
        _this.client_duration = 1000; // 客户端 - 更新时间间隔(毫秒)
        _this.update(data);
        return _this;
    }
    LoginInfo.prototype.relistObj = function (data, lKey) {
        if (data[lKey]) {
            var nlist = [];
            var list = data[lKey];
            for (var i = 0; i < list.length; i++) {
                nlist.push(new SheepInfo(list[i]));
            }
            this[lKey] = nlist;
        }
    };
    LoginInfo.prototype.update = function (data) {
        if (data == null) {
            return;
        }
        for (var key in data) {
            if ((data.hasOwnProperty(key)) && (key != "player" && key != "enemy" && key != "listRunning" && key != "listWaitSelf" && key != "listWaitEnemy")) {
                this[key] = data[key];
            }
        }
        if (data["player"]) {
            this.playerInfo = new PlayerInfo(data["player"]);
            this.client_sv_basic = this.client_max_lens / this.lens_way;
        }
        if (data["enemy"]) {
            this.enemy = new PlayerInfo(data["enemy"]);
        }
        this.relistObj(data, "listRunning");
        this.relistObj(data, "listWaitSelf");
        this.relistObj(data, "listWaitEnemy");
    };
    return LoginInfo;
}(BaseVO));
__reflect(LoginInfo.prototype, "LoginInfo");
var PlayerInfo = (function (_super) {
    __extends(PlayerInfo, _super);
    function PlayerInfo(data) {
        return _super.call(this, data) || this;
    }
    return PlayerInfo;
}(BaseVO));
__reflect(PlayerInfo.prototype, "PlayerInfo");
var SheepInfo = (function (_super) {
    __extends(SheepInfo, _super);
    function SheepInfo(data) {
        return _super.call(this, data) || this;
    }
    return SheepInfo;
}(BaseVO));
__reflect(SheepInfo.prototype, "SheepInfo");
//# sourceMappingURL=LoginInfo.js.map