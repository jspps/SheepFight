var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var SceneType = (function () {
    function SceneType() {
    }
    /**
     * 登陆界面
     */
    SceneType.LOGIN_SCENE = "loginScene";
    /** 等待玩家界面 */
    SceneType.WAIT_PLAYER = "waitPlayer";
    /** 游戏场景 */
    SceneType.GAME_SCENE = "gameScene";
    return SceneType;
}());
__reflect(SceneType.prototype, "SceneType");
//# sourceMappingURL=SceneType.js.map