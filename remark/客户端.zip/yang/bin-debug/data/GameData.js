var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var GameData = (function () {
    function GameData() {
    }
    GameData.getSheepSource = function (index) {
        if (index == 1)
            return "smallSheep_png";
        if (index == 2)
            return "middleSheep_png";
        if (index == 3)
            return "bigSheep_png";
        if (index == 4)
            return "neutralitySheep_png";
        if (index == 5)
            return "wolf_png";
        if (index == 6)
            return "vegetables_png";
        return "";
    };
    // public static userInfo: UserInfo;
    GameData.gameSceneEnterType = 1;
    /** 设置宽 */
    GameData.designWidth = 720;
    /** 设置高 */
    GameData.designHeight = 1280;
    /** 跑道拟定的总距离 */
    GameData.maxDistance = 10;
    /** 协议成功返回码 */
    GameData.success = "success";
    return GameData;
}());
__reflect(GameData.prototype, "GameData");
//# sourceMappingURL=GameData.js.map