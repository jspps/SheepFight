class SoundManager {
	/**
	 * 背景音乐音量。
	 * @default 1
	 */
	public static musicVolume: number = 1;
	/**
	 * 音效音量。
	 * @default 1
	 */
	public static soundVolume: number = 1;

	/**@private 当前播放的Channel列表。url->channel*/
	private static _channels: Object = {};
	/**@private 当前播放的Sound列表。url->sound*/
	private static _sounds: Object = {};
	/**@private 当前背景音乐url。*/
	private static _tMusic: string = null;
	/**@private 当前背景音乐声道。*/
	private static _musicChannel: egret.SoundChannel = null;

	public constructor() {
	}

	/**
	* 播放音效。音效可以同时播放多个。
	* @param url		声音文件地址。
	* @param loops		循环次数,0表示无限循环。
	* @param complete	声音播放完成回调
	* @param startTime	声音播放起始时间。
	* @return Sound对象，通过此对象可以对声音进行控制。
	*/
	public static playSound(url: string, loops: number = 1, complete: Function = null, startTime: number = 0): egret.SoundChannel {
		// console.log(">>playSound:",url,RES.getRes(url),SoundManager._sounds[url]);
		var tSound: egret.Sound;
		var channel: egret.SoundChannel;
		if(RES.getRes(url)!=null){
			SoundManager._sounds[url] = tSound = RES.getRes(url);
			// console.log(">>本地声音已加载，直接播放:",url,tSound);
			channel = tSound.play(startTime, loops);
			if(url.indexOf("bgm")!=-1){
				SoundManager._musicChannel=channel;
			}
			if (!channel) return;
			if (complete) channel.addEventListener(egret.Event.SOUND_COMPLETE, complete, this);
			channel.volume = url == SoundManager._tMusic ? SoundManager.musicVolume : SoundManager.soundVolume;
			SoundManager._channels[url] = channel;
			return channel;
		}else if(SoundManager._sounds[url]!=null){		
			tSound = SoundManager._sounds[url];
			// console.log(">>外部声音已加载，直接播放:",url,tSound);
			channel = tSound.play(startTime, loops);
			if(url.indexOf("bgm")!=-1){
				SoundManager._musicChannel=channel;
			}
			if (!channel) return;
			if (complete) channel.addEventListener(egret.Event.SOUND_COMPLETE, complete, this);
			channel.volume = url == SoundManager._tMusic ? SoundManager.musicVolume : SoundManager.soundVolume;
			SoundManager._channels[url] = channel;
			return channel;
		}else{
			// console.log(">>外部声音未加载：",url);
			tSound = new egret.Sound();
			tSound.addEventListener(egret.Event.COMPLETE, function (e: egret.Event) {
				// console.log(">>外部声音加载成功并播放:",url,tSound);
				SoundManager._sounds[url]=tSound;
				var channel: egret.SoundChannel = tSound.play(startTime, loops);
				if(url.indexOf("bgm")!=-1){
					SoundManager._musicChannel=channel;
				}
				if (!channel) return;
				if (complete) channel.addEventListener(egret.Event.SOUND_COMPLETE, complete, this);
				channel.volume = url == SoundManager._tMusic ? SoundManager.musicVolume : SoundManager.soundVolume;
				SoundManager._channels[url] = channel;
				return channel;
			}, this);
			tSound.load(url);
		}
	}

	/**
	* 播放背景音乐。背景音乐同时只能播放一个，如果在播放背景音乐时再次调用本方法，会先停止之前的背景音乐，再播发当前的背景音乐。
	* @param url		声音文件地址。
	* @param loops		循环次数,0表示无限循环。
	* @param complete	声音播放完成回调。
	* @param startTime	声音播放起始时间。
	* @return SoundChannel对象，通过此对象可以对声音进行控制，以及获取声音信息。
	*/
	public static playMusic(url: string, loops: number = 1, complete: Function = null, startTime: number = 0) {
		// console.log(">>playMusic1:",SoundManager._tMusic,url);
		// if(SoundManager._tMusic==url)return;
		// console.log(">>playMusic2:",SoundManager._tMusic,url);
		SoundManager._tMusic = url;
		if (SoundManager._musicChannel) SoundManager._musicChannel.stop();
		SoundManager._musicChannel = SoundManager.playSound(url, loops, complete, startTime);
	}

	/**
	* 关闭声音流
	* @param url 声音路径
	*/
	public static destroySound(url: string): void {
		for (var key in SoundManager._sounds) {
			if (SoundManager._sounds.hasOwnProperty(key)) {
				var sound: egret.Sound = SoundManager._sounds[key];
				if (key == url) {
					sound.close();
				}
			}
		}
	}

	/**
	* 停止声音播放。此方法能够停止任意声音的播放（包括背景音乐和音效），只需传入对应的声音播放地址。
 	* @param url  声音文件地址。
	 */
	public static stopSound(url: String): void {
		for (var key in SoundManager._channels) {
			if (SoundManager._channels.hasOwnProperty(key)) {
				var channel: egret.SoundChannel = SoundManager._channels[key];
				if (key == url) channel.stop();
			}
		}
		if(SoundManager._tMusic==url){
			SoundManager._tMusic="";
		}
	}

	/**
	 * 停止播放所有音效（不包括背景音乐）。
	 */
	public static stopAllSound() {
		for (var key in SoundManager._channels) {
			if (SoundManager._channels.hasOwnProperty(key)) {
				var channel: egret.SoundChannel = SoundManager._channels[key];
				if (key != SoundManager._tMusic) channel.stop();
			}
		}
	}

	/**
	 * 停止播放所有声音（包括背景音乐和音效）。
	 */
	public static stopAll(): void {
		SoundManager._tMusic = null;
		for (var key in SoundManager._channels) {
			if (SoundManager._channels.hasOwnProperty(key)) {
				var channel: egret.SoundChannel = SoundManager._channels[key];
				channel.stop();
			}
		}
	}

	/**
	 * 停止播放背景音乐（不包括音效）。
	 * @param url  声音文件地址。
	 */
	public static stopMusic(): void {
		// console.log(">>stopMusic:",SoundManager._musicChannel);
		if (SoundManager._musicChannel) SoundManager._musicChannel.stop();
		SoundManager._tMusic = null;
	}

	/**
	* 设置声音音量。根据参数不同，可以分别设置指定声音（背景音乐或音效）音量或者所有音效（不包括背景音乐）音量。
	* @param volume	音量。初始值为1。音量范围从 0（静音）至 1（最大音量）。
	* @param url		(default = null)声音播放地址。默认为null。为空表示设置所有音效（不包括背景音乐）的音量，不为空表示设置指定声音（背景音乐或音效）的音量。
	*/
	public static setSoundVolume(volume: number, url: string = null): void {
		// if (url) {
		// 	SoundManager.setVolume(url, volume);
		// } else {
		// 	SoundManager.soundVolume = volume;
		// 	for (var key in SoundManager._channels) {
		// 		if (SoundManager._channels.hasOwnProperty(key)) {
		// 			var channel: egret.SoundChannel = SoundManager._channels[key];
		// 			if (key != SoundManager._tMusic) channel.volume = volume;
		// 		}
		// 	}
		// }
		// console.log(">>setSoundVolume:",volume,url,SoundManager._sounds[url],SoundManager._channels[url])
		if (SoundManager._sounds[url]) {
			if(!SoundManager._channels[url]){
				SoundManager._channels[url] = SoundManager._sounds[url].play(0);
			}
			SoundManager._channels[url].volume = volume;
		} 
	}

	/**
	* 设置背景音乐音量。音量范围从 0（静音）至 1（最大音量）。
	* @param volume	音量。初始值为1。音量范围从 0（静音）至 1（最大音量）。
	*/
	public static setMusicVolume(volume: number): void {
		SoundManager.musicVolume = volume;
		if (SoundManager._musicChannel)
			SoundManager._musicChannel.volume = volume;
	}

	/**
 	* 设置指定声音的音量。
	* @param url		声音文件url
 	* @param volume	音量。初始值为1。
	*/
	private static setVolume(url: string, volume: number): void {
		for (var key in SoundManager._channels) {
			if (SoundManager._channels.hasOwnProperty(key)) {
				var channel: egret.SoundChannel = SoundManager._channels[key];
				if (key == url) {
					var sound:egret.Sound = SoundManager._sounds[key];
					if(sound != null){
						sound.play();
					}
					channel.volume = volume;
				}
			}
		}
	}

	public static loadSound(url: string): void {
		if(SoundManager._sounds[url]!=null){
			console.log(">>声音资源已加载：",url);
			return;
		}
        var sound: egret.Sound = new egret.Sound();
        //sound 加载完成监听
		var that=this;
        sound.addEventListener(egret.Event.COMPLETE, function (e: egret.Event) {
            SoundManager._sounds[url]=sound;
        }, this);
        sound.load(url);
    }

}