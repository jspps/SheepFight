class SceneManager extends egret.Sprite {
    // 场景控制器的单例
    private static instance: SceneManager;
    // 登陆
    public loginScene: LoginScene;
    //前一个场景
    private preScene;
    //当前场景类型
    public curSceneType: string;

    private gameScene: GameScene;
    private waitPlayer: WaitPlyer;

    private sceneLayer: egret.Sprite;
    private popupLayer: egret.Sprite;
    private topLayer: egret.Sprite;

    private btnGameClub;
    public constructor() {
        super();
        this.init();
    }

    public init() {
        this.sceneLayer = new egret.Sprite();
        this.addChild(this.sceneLayer);
        this.popupLayer = new egret.Sprite();
        this.addChild(this.popupLayer);
        this.topLayer = new egret.Sprite();
        this.addChild(this.topLayer);
        // 默认添加开始场景
        this.changeScene(SceneType.LOGIN_SCENE);
    }

    // 实例化单例获取方法
    public static getInstance(): SceneManager {
        if (!SceneManager.instance) {
            SceneManager.instance = new SceneManager();
        }
        return SceneManager.instance;
    }

    private initScene(type: string) {
        switch (type) {
            case SceneType.LOGIN_SCENE:
                if (this[type] == null) {
                    this[type] = new LoginScene();
                }
                break;
            case SceneType.GAME_SCENE:
                if (this.gameScene == null) {
                    this.gameScene = new GameScene();
                }
                break;
            case SceneType.WAIT_PLAYER:
                if (this[type] == null) {
                    this[type] = new WaitPlyer();
                }
                break;
        }
    }

    // 切换场景
    public changeScene(type) {
        console.log(">>changeScene:", this.preScene, type);
        if (this.preScene && this.preScene == this[type]) {
            return;
        }
        // 释放当前场景资源
        // if (this.preScene) {
        //     this.preScene.baseGC();
        //     this.sceneLayer.removeChild(this.preScene);
        // }
        // 添加下一个场景
        this.curSceneType = type;
        this.initScene(type);
        // console.log(">>changeScene:",type,this[type]);
        this.sceneLayer.addChild(this[type]);
        this[type].init();
        this.preScene = this[type];
    }
    private _timeId: number
    public openTime(duration : number = 1000) {
        GameData.loginInfo.client_duration = duration;
        this._timeId = setInterval(() => {
            this.startTime();
        },duration)
    }

    public clearTime() {
        clearInterval(this._timeId);
    }

    public reOpenTime(duration : number = 1000) {
        this.clearTime();
        this.openTime(duration);
    }

    private startTime() {
        //请求心跳
        this.httpHeartBeat();
        if (this.gameScene && this.gameScene.parent) {
            this.gameScene.loop();
        }
    }

    private httpHeartBeat() {
        let obj = `&sesid=${GameData.loginInfo.sesid}`;
        NetManager.getInstance().httpSendData(NetManager.HTTP_HEARTBEAT, obj, (data) => {
            let msg = data[`msg`]
            if (msg && msg[`isEnd`]) {//游戏结束
                if(msg["isWin"]){
                    Toast.launch(`恭喜你，取得胜利!`)
                }else{
                    Toast.launch(`很遗憾，挑战失败！`)
                }
                this.reOpenTime();
                return;
            }
            GameData.loginInfo.update(msg);
            if (msg && msg[`start`] == 1) {//游戏开始
                if (this.waitPlayer) this.waitPlayer.baseGC();
                this.reOpenTime(200);
                this.changeScene(SceneType.GAME_SCENE);
            }
            if (this.gameScene && this.gameScene.parent) {
                this.gameScene.updateAllSheepInfo();
            }
        })
    }

}