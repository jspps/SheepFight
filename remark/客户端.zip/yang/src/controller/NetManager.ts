class NetManager {
	// 网络控制器的单例
	private static instance: NetManager;

	private httpServerUrl: string = "http://60.205.217.89:8080/SheepFight/Svlet/Game";//正式服地址 60.205.217.89  127.0.0.1

	public isSocketOpen: boolean = false;

	/**
	 * 获取服务器时间
	 */
	public static HTTP_SERVER_TIME: number = 100;
	/**
	 * 登陆
	 */
	public static HTTP_LOGIN: number = 1000;
	/**
	 * 放羊
	 */
	public static HTTP_DOWN_SHEEP: number = 1010;
	/**
	 * 心跳
	 */
	public static HTTP_HEARTBEAT: number = 1001;

	public constructor() {

	}

	// 实例化单例获取方法
	public static getInstance(): NetManager {
		if (!NetManager.instance) {
			NetManager.instance = new NetManager();
		}
		return NetManager.instance;
	}

	/**
	 * http发送数据
	 * @param url 地址
	 * @param data 数据
	 * @param callBack 回调函数
	 */
	public httpSendData(msgName: number, data: any, callBack?: Function) {
		var url: string = this.httpServerUrl;
		var strData : string = `cmd=${msgName}${data}`;
		var sendVO: HttpSendVO = new HttpSendVO(url,strData,callBack);
		new HttpCommon(sendVO);
	}
}