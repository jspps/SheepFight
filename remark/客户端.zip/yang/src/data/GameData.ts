class GameData {
	// public static userInfo: UserInfo;
	public static gameSceneEnterType: number = 1;
	public static windowWidth: number;//设备屏幕宽度
	public static windowHeight: number;//设备屏幕高度
	public static gameSceneY: number;
	public static query: Object;
	public static main: Main;
	/** 是否随机皮肤 */
	public static isRandomSkin: boolean;
	/** 设置宽 */
	public static designWidth = 720;
	/** 设置高 */
	public static designHeight = 1280;
	/** 玩家自己的信息 */
	public static loginInfo: LoginInfo;
	/** 对手的信息 */
	public static enemyInfo: LoginInfo;
	/** 跑道拟定的总距离 */
	public static maxDistance: number = 10;

	/** 协议成功返回码 */
	public static success = `success`;
	public constructor() {
	}

	public static getSheepSource(index: number) {
		if (index == 1) return `smallSheep_png`;
		if (index == 2) return `middleSheep_png`;
		if (index == 3) return `bigSheep_png`;
		if (index == 4) return `neutralitySheep_png`;
		if (index == 5) return `wolf_png`;
		if (index == 6) return `vegetables_png`;
		return ``;
	}
}