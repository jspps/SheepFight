class SceneType {
	/**
	 * 登陆界面
	 */
	public static LOGIN_SCENE: string = "loginScene";
	/** 等待玩家界面 */
	public static WAIT_PLAYER: string = "waitPlayer";
	/** 游戏场景 */
	public static GAME_SCENE: string = "gameScene";
}