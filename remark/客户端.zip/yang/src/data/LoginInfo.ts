class LoginInfo extends BaseVO {
	public roomId:string;
	/** 跑道中的信息列表 */
	public listRunning: Array<SheepInfo>;
	public time_ms: number;
	public lens_way : number = 1;
	public sesid: string;
	/** 自己的信息 */
	public playerInfo: PlayerInfo;
	/** 敌人的信息 */
	public enemy: PlayerInfo;
	/** 等待区羊的信息列表 */
	public listWaitSelf: Array<SheepInfo>;
	public listWaitEnemy: Array<SheepInfo>;
	public client_max_lens : number = 1000; // 客户端 跑道总长
	public client_sv_basic : number = 1; // 客户端 - 服务器 比例值
	public client_duration : number = 1000; // 客户端 - 更新时间间隔(毫秒)
	public constructor(data: Object) {
		super(data);
		this.update(data);
	}

	private relistObj(data: Object,lKey : string) {
		if (data[lKey]) {
			var nlist = [];
			let list = data[lKey];
			for(var i = 0; i < list.length;i++){
				nlist.push(new SheepInfo(list[i]));
			}
			this[lKey] = nlist;
		}
	}

	public update(data: Object) {
		if (data == null) {
			return;
		}
		for (var key in data) {
			if((data.hasOwnProperty(key)) && (key != "player" && key != "enemy" && 	key != "listRunning" && key != "listWaitSelf" && key != "listWaitEnemy"))
			{
				this[key] = data[key];
			}
		}

		if (data[`player`]) {
			this.playerInfo = new PlayerInfo(data[`player`]);
			this.client_sv_basic = this.client_max_lens / this.lens_way;
		}

		if (data[`enemy`]) {
			this.enemy = new PlayerInfo(data[`enemy`]);
		}
		this.relistObj(data,"listRunning");
		this.relistObj(data,"listWaitSelf");
		this.relistObj(data,"listWaitEnemy");
	}
}

class PlayerInfo extends BaseVO {
	public icon: number;
	public name: string;
	/** 草料数 */
	public forage: number;
	public constructor(data: Object) {
		super(data);
	}
}

class SheepInfo extends BaseVO {
	public id: string;
	/** 拥有者的id 按照出身点坐标计算 */
	public belongTo: string;
	public distance: number;
	/** 索引 */
	public index: number;
	public endDistance: number;
	/** 是否在移动 */
	public isRunning: boolean;
	/**  */
	public speed: number;
	public runway: number;
	public name: string;
	public power: number;
	/** 朝向 */
	public runTo: string;
	public constructor(data: Object) {
		super(data);
	}
}