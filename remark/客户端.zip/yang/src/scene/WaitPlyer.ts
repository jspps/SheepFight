class WaitPlyer extends eui.Component implements IBaseGC {
	public constructor() {
		super()
		this.skinName = `WaitPlayerSkin`;
	}

	public init() {
	}
	public baseGC() {
		this.removeSelf();
	}
}