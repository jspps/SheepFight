class LoginScene extends eui.Component implements IBaseGC {
	public _account: eui.TextInput;
	public _password: eui.TextInput;
	public _loginBtn: eui.Button;

	public constructor() {
		super();
		this.skinName = `loginSkin`;
	}

	public init() {
		this._account.text = `sun1`;
		this._loginBtn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.loginClick, this);
	}

	public loginClick() {
		if (this._account.text.length <= 0 || this._password.text.length <= 0) {
			Toast.launch(`账号密码不能为空`)
			return;
		}
		let obj = `&lgid=${this._account.text}&lgpwd=${this._password.text}`;
		NetManager.getInstance().httpSendData(NetManager.HTTP_LOGIN, obj, (data) => {
			GameData.loginInfo = new LoginInfo(data[`msg`]);
			SceneManager.getInstance().reOpenTime();
			this.baseGC();
		})
	}

	public baseGC() {
		this._loginBtn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.loginClick, this);
		this.removeSelf();
		SceneManager.getInstance().changeScene(SceneType.WAIT_PLAYER);
	}
}