class GameScene extends eui.Component implements IBaseGC {
	public _row1: eui.Group;
	public _row2: eui.Group;
	public _row3: eui.Group;
	public _row4: eui.Group;
	public _row5: eui.Group;
	public _selfHp: eui.ProgressBar;
	public _enemyHp: eui.ProgressBar;
	public _enemyWait: WaitSheep;
	public _selfWait0: WaitSheep;
	public _selfWait1: WaitSheep;
	public _selfWait2: WaitSheep;

	private _sheeps: Array<SheepItem>;//羊的列表
	private _movedis: number;//移动距离基础值
	private _deleteSheeps: Array<SheepItem>;//移除的羊的列表
	public constructor() {
		super();
		this.skinName = `GameSceneSkin`;
	}

	public init() {
		this._sheeps = [];
		for (let i = 1; i <= 5; i++) {
			this[`_row${i}`].touchChildren = false;
			this[`_row${i}`].addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickRow, this)
		}
		this._selfHp.minimum = this._enemyHp.minimum = 0;
		this._selfHp.maximum = this._enemyHp.maximum = 100;
		this._selfHp.value = this._enemyHp.value = 100;
		this.updateInfo();
	}

	private updateInfo() {
		this.showWaitSheep();
		this.showAge();
	}

	//展示等待区羊
	private showWaitSheep() {
		let mySheeps = GameData.loginInfo.listWaitSelf;
		let enemySheeps = GameData.loginInfo.listWaitEnemy;
		if (mySheeps) {
			mySheeps.forEach((sheepInfo, index) => {
				this[`_selfWait${index}`].init(sheepInfo);
			});
		}
		if (enemySheeps && enemySheeps.length) {
			this._enemyWait.init(enemySheeps[0]);
		}
	}

	private showAge() {
		this._selfHp.value = GameData.loginInfo.playerInfo.forage;
		this._enemyHp.value = GameData.loginInfo.enemy.forage;
	}

	private onClickRow(e: egret.TouchEvent) {
		let target = e.target;
		let row: number = 0;
		for (let i = 1; i <= 5; i++) {
			if (target == this[`_row${i}`]) {
				row = i;
				break;
			}
		}
		console.log(`>>placeSheep`, row)
		this.placeSheep(row);
	}

	private placeSheep(row: number) {
		let mySheeps = GameData.loginInfo.listWaitSelf;
		if (mySheeps && mySheeps.length) {
			let sheep = mySheeps[0];
			let obj = `&sesid=${GameData.loginInfo.sesid}&sheepId=${sheep.id}&runway=${row}`;
			NetManager.getInstance().httpSendData(NetManager.HTTP_DOWN_SHEEP, obj, (data) => {
				mySheeps.remove(sheep);
			})
		}else{
			Toast.launch(`等待区，无羊了!`)
		}
	}

	//更新所有的羊信息
	public updateAllSheepInfo() {
		this.updateInfo();//更新界面信息
		//更新场上的羊
		this._deleteSheeps = [];
		while (this._sheeps.length) {
			this._deleteSheeps.push(this._sheeps.pop());
		}
		let selfRun = GameData.loginInfo.listRunning;
		this.updateRunSheep(selfRun);

		let sheepCount = this._deleteSheeps.length;
		for (let i = sheepCount - 1; i >= 0; i--) {
			let sheep = this._deleteSheeps[i];
			sheep.baseGC();
		}
	}

	private updateRunSheep(runList: Array<SheepInfo>) {
		for (let i = 0; i < runList.length; i++) {
			let sheepInfo = runList[i];
			let findSheep = this.findMoveSheep(sheepInfo.id);
			if (findSheep) {
				findSheep.sheepInfo = sheepInfo;
				if(sheepInfo.isRunning){
					findSheep.move();
				}
				this._sheeps.push(findSheep);
				this[`_row${sheepInfo.runway}`].addChild(findSheep);
			}
			else {
				let sheepItem: SheepItem = Pool.getItemByClass(`sheep`, SheepItem);
				sheepItem.sheepInfo = sheepInfo;
				this[`_row${sheepInfo.runway}`].addChild(sheepItem);
				this._sheeps.push(sheepItem);
				sheepItem.move(false);
			}
		}
	}

	private findMoveSheep(sheepId: string) {
		let sheepCount = this._deleteSheeps.length;
		for (let i = sheepCount - 1; i >= 0; i--) {
			let sheep = this._deleteSheeps[i];
			if (sheep.sheepInfo.id == sheepId) {
				this._deleteSheeps.remove(sheep);
				return sheep;
			}
		}
		return null;
	}

	private updateSheep(sheep: SheepItem, sheepInfo: SheepInfo) {
		sheep.sheepInfo = sheepInfo;
		sheep.move();
	}

	public loop() {
		// this._sheeps.forEach(sheep => {
		// 	sheep.move();
		// });
	}

	public baseGC() {
		for (let i = 1; i <= 5; i++) {
			this[`_row${i}`].removeEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickRow, this)
		}
		this.removeSelf();
	}
}