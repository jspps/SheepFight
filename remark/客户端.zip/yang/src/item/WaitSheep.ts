class WaitSheep extends eui.Component {
	public _role: eui.Image;
	public _power: eui.Label;

	public constructor() {
		super();
		this.skinName = `WaitSheepSkin`;
	}

	public init(sheepInfo: SheepInfo) {
		this._role.source = GameData.getSheepSource(sheepInfo.index);
		this._power.text = sheepInfo.power + ``;//力量值
	}
}