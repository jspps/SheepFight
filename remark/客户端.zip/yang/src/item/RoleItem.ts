class RoleItem extends eui.Component {
	public _role: eui.Image;

	public constructor() {
		super();
		this.skinName = `RoleSkin`;
	}

	/** 角色信息 */
	private _sheepInfo: SheepInfo;
	public get sheepInfo(): SheepInfo {
		return this._sheepInfo;
	}
	public set sheepInfo(v: SheepInfo) {
		this._sheepInfo = v;
		this._role.source = GameData.getSheepSource(v.index);
	}

	public move(addTween: boolean = true) {
		egret.Tween.removeTweens(this);
		var basic = GameData.loginInfo.client_sv_basic;
		let mY = basic * this.sheepInfo.distance;
		var initPos = (GameData.loginInfo.lens_way - this.sheepInfo.endDistance) * basic;
		let endy = Math.floor(initPos + mY);
		if (this.sheepInfo.runTo != GameData.loginInfo.sesid) {
			// 向敌人靠近
			var max = GameData.loginInfo.client_max_lens;
			endy = Math.floor(max - endy);
			// console.log("==Toenm = " + initPos + ",mY =" + mY + ",endy = " + endy);
		}

		if (endy == this.y) return;
		if (addTween) egret.Tween.get(this).to({ y: endy },GameData.loginInfo.client_duration);
		else this.y = endy;
	}

	public baseGC() {
		this.removeSelf();
	}
}