class WolfItem extends RoleItem {
	public constructor() {
		super();
	}
}