class SheepItem extends RoleItem {
	public constructor() {
		super();
	}

	public baseGC() {
		super.baseGC();
		Pool.recover(`sheep`, this);
	}
}