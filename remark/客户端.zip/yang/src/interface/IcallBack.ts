interface IcallBack{
    _callBack:Function
    setCallBack(fun:Function);
    callBackEvent(name:string,data:any,type:string);
}