interface IBaseGC{
    init();
    baseGC();
}