class HttpCommon {
	private _sendVO: HttpSendVO;
	public constructor(sendVO) {
		this._sendVO = sendVO;
		var request = new egret.HttpRequest();
		request.responseType = egret.HttpResponseType.TEXT;
		request.setRequestHeader("content-type", "application/x-www-form-urlencoded;charset=utf-8");
		// if(GameData.recLoginServerData != null && GameData.recLoginServerData.session_id != null && GameData.recLoginServerData.session_id != ""){
		// 	request.setRequestHeader("Cookie","PHPSESSID="+GameData.recLoginServerData.session_id);
		// }
		request.open(this._sendVO.sendURL, egret.HttpMethod.POST);
		request.send(this._sendVO.dataObj);

		// console.log("发送Http数据:",this._sendVO.sendURL,JSON.stringify(this._sendVO.dataObj));
		request.addEventListener(egret.Event.COMPLETE, this.onPostComplete, this);
		request.addEventListener(egret.IOErrorEvent.IO_ERROR, this.onPostIOError, this);
		request.addEventListener(egret.ProgressEvent.PROGRESS, this.onPostProgress, this);
	}
	private onPostComplete(event: egret.Event): void {
		var request = <egret.HttpRequest>event.currentTarget;
		// console.log("== http = :" + request.response);
		let data = JSON.parse(request.response);
		if (data[`code`] != GameData.success) {
			Toast.launch(data[`msg`][`tip`]);
			return;
		}
		if (this._sendVO.callBack != null) {
			this._sendVO.callBack(data);
		}
		this._sendVO.gc();
	}
	private onPostIOError(event: egret.IOErrorEvent): void {
		console.log("post error : ", event);
	}
	private onPostProgress(event: egret.ProgressEvent): void {
		// console.log("post progress : " + Math.floor(100 * event.bytesLoaded / event.bytesTotal) + "%");
	}
}