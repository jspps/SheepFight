class HttpSendVO  {
	public sendURL:string;
	public dataObj:any;
	public callBack:Function;
	public constructor(url:string,data:any,_callBack?:Function) {
		this.sendURL=url;
		this.dataObj=data;
		this.callBack=_callBack;
	}
	
	public get sendVOStr():string{
		var _str:string="sendURL:"+this.sendURL+",sendData:"+this.sendStr;
		return _str;
	}

	public get sendStr() : string {
		var _str:string="";
		if(this.dataObj as Object ){
			_str=JSON.stringify(this.dataObj);
		}else if(this.dataObj as string){
			_str=this.dataObj;
		}
		return _str;
	}

	public gc(){
		this.callBack=null;
		this.dataObj=null;
	}
}