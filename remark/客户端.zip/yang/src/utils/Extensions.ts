/**
 * 拓展ts原生类
 */
namespace Extensions {
    //#region
    /** 
     * 随机一个范围内的数字（整数），范围的左边是闭区间，右边是开区间
     */
    //#endregion
    function random(min: number, max: number) {
        let d = Math.floor(max) - Math.floor(min);
        return min + Math.floor(Math.random() * d);
    }

    function getValue(obj, lambda) {
        if (!lambda) {
            return obj;
        } else {
            return lambda(obj);
        }
    }

    function defineToObject(methodName, value) {
        Object.defineProperty(Object.prototype, methodName, {
            enumerable: false,
            configurable: true,
            writable: true,
            value: value
        });
    }

    export function initExtensions() {

        Array.prototype.pushRange = function (items) {
            if (!items || items.length == 0) {
                return;
            }
            for (var x of items) {
                this.push(x);
            }
        };

        Array.prototype.contains = function (item) {
            return this.indexOf(item) >= 0;
        };

        Array.prototype.first = function (lambda) {
            if (!lambda && this.length > 0) {
                return this[0];
            }
            for (var x of this) {
                if (lambda(x)) {
                    return x;
                }
            }
            return null;
        };

        Array.prototype.last = function (lambda) {
            if (!lambda && this.length > 0) {
                return this[this.length - 1];
            }
            for (let i = this.length - 1; i >= 0; i--) {
                if (lambda(this[i])) {
                    return this[i];
                }
            }
            return null;
        };

        Array.prototype.max = function (lambda) {
            let result = null;
            if (this.length == 0)
                return result;
            let max = getValue(this[0], lambda);
            result = this[0];
            for (let i = 1; i < this.length; i++) {
                let temp = getValue(this[i], lambda);
                if (temp > max) {
                    max = temp;
                    result = this[i];
                }
            }
            return result;
        };

        Array.prototype.min = function (lambda) {
            let result = null;
            if (this.length == 0)
                return result;
            let min = getValue(this[0], lambda);
            result = this[0];
            for (let i = 1; i < this.length; i++) {
                let temp = getValue(this[i], lambda);
                if (temp < min) {
                    min = temp;
                    result = this[i];
                }
            }
            return result;
        };

        Array.prototype.Contains = function (lambda) {
            return this.first(lambda) != null;
        };

        Array.prototype.remove = function (item) {
            const ndx = this.indexOf(item);
            if (ndx >= 0) {
                let last = this.length - 1;
                let temp = this[last];
                this[last] = this[ndx];
                this[ndx] = temp;
                this.pop();
            }
        };

        Array.prototype.removeBySlice = function (item) {
            const ndx = this.indexOf(item);
            if (ndx >= 0) {
                this.splice(ndx, 1);
            }
        };

        Array.prototype.Remove = function (lambda) {
            let delectItem = (idx: number) => {
                let last = this.length - 1;
                let temp = this[last];
                this[last] = this[idx];
                this[idx] = temp;
                this.pop();
            };

            let delectCount = 0;
            for (let i = 0; i < this.length; i++) {
                if (lambda(this[i])) {
                    delectItem(i);
                    delectCount++;
                    i--;
                }
            }
            return delectCount;
        };


        Array.prototype.clear = function () {
            let cnt = this.length;
            for (let i = 0; i < cnt; i++) {
                this.pop();
            }
        };

        Array.prototype.select = function (lambda) {
            return this.map(lambda);
        };

        Array.prototype.where = function (lambda) {
            return this.filter(lambda);
        };

        Array.prototype.count = function (lambda) {
            if (!lambda) return this.length;
            return this.where(lambda).length;
        };

        Array.prototype.toDictionary = function (lambda) {
            let obj = {};
            for (var x of this) {
                obj[lambda(x)] = x;
            }
            return obj;
        };

        //TODO:luowende 暂时实现方法，存在丢弃构造函数的bug
        Array.prototype.clone = function () {
            // return JSON.parse(JSON.stringify(this));
            return this.slice(0);
        };

        Array.prototype.Shuffle = function () {
            for (let i = 0; i < this.length; i++) {
                let randIdx = random(0, this.length);
                //当前元素与随机一个位置元素交换位置
                var temp = this[i];
                this[i] = this[randIdx];
                this[randIdx] = temp;
            }
        };

        Array.prototype.shuffle = function () {
            let newArr = this.clone();
            newArr.Shuffle();
            return newArr;
        };

        Array.prototype.SortAsc = function (lambda) {
            this.sort((a, b) => getValue(a, lambda) - getValue(b, lambda));
        };

        Array.prototype.SortDesc = function (lambda) {
            this.sort((a, b) => getValue(b, lambda) - getValue(a, lambda));
        };

        Array.prototype.sortAsc = function (lambda) {
            let newArr = this.clone();
            newArr.SortAsc(lambda);
            return newArr;
        };

        Array.prototype.sortDesc = function (lambda) {
            let newArr = this.clone();
            newArr.SortDesc(lambda);
            return newArr;
        };

        Array.prototype.DeleteSame = function (lambda) {
            let hash: any = {};
            let newArr = [];
            for (let item of this) {
                let value = lambda(item);
                if (hash[value])
                    continue;
                newArr.push(item);
                hash[value] = 1;
            }
            return newArr;
        };

        Array.prototype.AllSame = function (arr: Array<any>) {
            for (var index = 0; index < arr.length; index++) {
                var element = arr[index];
                if (this.indexOf(element) != -1) {
                    return false;
                }
            }
            return true;
        }

        egret.DisplayObjectContainer.prototype.removeSelf = function () {
            if (this.parent) {
                this.parent.removeChild(this);
            }
        }
        let colorFlilter = new egret.ColorMatrixFilter([
            0.3, 0.6, 0, 0, 0,
            0.3, 0.6, 0, 0, 0,
            0.3, 0.6, 0, 0, 0,
            0, 0, 0, 1, 0
        ]);

        Object.defineProperty(egret.DisplayObject.prototype, "gray", {
            set: function (v) {
                this.filters = v ? [colorFlilter] : [];
            },
            enumerable: false,
            configurable: true
        });

        Object.defineProperty(egret.DisplayObject.prototype, "enabeled", {
            set: function (v) {
                this.touchEnabled = v;
                this.filters = v ? [] : [colorFlilter];
            },
            enumerable: false,
            configurable: true
        });

    }
}


interface Array<T> {

    /**
     * 添加一个数组
     */
    pushRange(items: Array<T>): void;

    /**
     * 确定数组中是否存在某个具体元素
     */
    contains(item: T): boolean;

    /**
     * 确定数组中是否存在满足条件的元素
     */
    Contains(lambda: (item: T) => boolean): boolean;

    /**
     * 删除某一项
     */
    remove(item: T): void;
    /**
     * 删除某一项 不改变数组数据顺序
     */
    removeBySlice(item: T): void;

    /**
     * 删除满足条件的元素，返回删除的数量
     */
    Remove(lambda: (item: T) => boolean): number;

    /**
     * 清空数组
     */
    clear();

    /**
     * 寻找第一个符合条件的元素
     * 如果条件不传，则直接返回第0个元素
     */
    first(lambda?: (item: T) => boolean): T;

    /**
     * 寻找最后一个符合条件的元素
     * 如果条件不传，则直接返回最后一个元素
     */
    last(lambda?: (item: T) => boolean): T;

    /**
     * 将lambda作为转换函数作用于每个元素上，返回最大结果的那个元素
     * @param lambda 转换函数
     */
    max<R>(lambda?: (item: T) => R): T;

    /**
     * 将lambda作为转换函数作用于每个元素上，返回最小结果的那个元素
     * @param lambda 转换函数
     */
    min<R>(lambda?: (item: T) => R): T;

    /**
     * 将序列中的每个元素投影到新表中
     */
    select<R>(lambda: (item: T) => R): Array<R>;

    /**
     * 筛选出满足条件的元素
     */
    where(lambda: (item: T) => boolean): Array<T>;

    /**
     * 统计数组中满足条件的元素数量
     * 如果不传条件则直接返回数组的长度
     */
    count(lambda?: (item: T) => boolean): number;

    /**
     * 将数组转化为Object
     * 将lambda作为转换函数作用于每个元素上，构建Dictionary的key
     * @param lambda key的转换函数
     */
    toDictionary(lambda: (item: T) => string | number): { [key: string]: T };

    /**
     * 克隆一个数组
     */
    clone(): Array<T>;

    /**
     * 将数组【本身】随机打乱
     */
    Shuffle(): void;

    /**
     * 【返回】随机打乱后的数组
     */
    shuffle(): Array<T>;

    /**
     * 小 ---> 大 排列【返回】排序好的数组
     * @param lambda 用哪个字段进行排序
     */
    sortAsc<R>(lambda?: (item: T) => R): Array<T>;

    /**
     * 大 ---> 小 排列 【返回】排序好的数组
     * @param lambda 用哪个字段进行排序
     */

    sortDesc<R>(lambda?: (item: T) => R): Array<T>;

    /**
     * 小 ---> 大 排列 直接把【本身】数组排好序
     * @param lambda 用哪个字段进行排序
     */
    SortAsc<R>(lambda?: (item: T) => R): void;

    /**
     * 小 ---> 大 排列 直接把【本身】数组排好序，如果有多个参考字段，可以传多个参数
     * @param lambdas 用哪个字段进行排序（可以无限传）
     */
    SortAsc<R>(...lambdas: Array<(item: T) => R>): void;

    /**
     * 大 ---> 小 排列 直接把【本身】数组排好序
     * @param lambda 用哪个字段进行排序
     */
    SortDesc<R>(lambda?: (item: T) => R): void;

    /**
     * 大 ---> 小 排列 直接把【本身】数组排好序，如果有多个参考字段，可以传多个参数
     * @param lambda 用哪个字段进行排序（可以无限传）
     */
    SortDesc<R>(...lambdas: Array<(item: T) => R>): void;

    /**
     * 删除相同的元素
     */
    DeleteSame<R>(lambda?: (item: T) => R): Array<T>;

    /**
     * 两个数组是否完全相同
     * @param arr 比较的目标数组 
     */
    AllSame<R>(arr: Array<R>): boolean;

}

module egret {
    export interface DisplayObjectContainer {
        removeSelf(): void;
        gray: boolean;
        /** 是否可用 */
        enabeled: boolean;
    }
    export interface DisplayObject {
        gray: boolean;
        /** 是否可用 */
        enabeled: boolean;
    }
}